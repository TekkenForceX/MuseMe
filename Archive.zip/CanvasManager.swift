//
//  CanvasManager.swift
//  MuseMe
//
//  Created by Matthew Fails on 5/9/24.
//

import SwiftUI

struct CanvasManager: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    CanvasManager()
}
