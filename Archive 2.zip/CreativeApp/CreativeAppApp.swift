//
//  CreativeAppApp.swift
//  CreativeApp
//
//  Created by Matthew Fails on 1/29/24.
//

import SwiftUI



struct CreativeAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
