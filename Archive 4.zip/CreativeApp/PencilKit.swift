//
//  Pencil Kit.swift
//  MuseMe
//
//  Created by Matthew Fails on 5/2/24.
//

import SwiftUI
import PencilKit  // Assuming you want to use the actual PencilKit framework

struct MyPencilKitView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct MyPencilKitView_Previews: PreviewProvider {
    static var previews: some View {
        MyPencilKitView()
    }
}





// updateded
